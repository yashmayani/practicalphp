<?php

$a=1;
// while ($a <= 100) {
//     echo $a++;
//     echo "<br>";
// }


do {
    echo $a++;
    echo "<br>";
} while ($a <= 100);



?>