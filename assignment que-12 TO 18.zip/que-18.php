<?php
$a="324";
 $b= (integer)$a;


 echo gettype($b);

?>