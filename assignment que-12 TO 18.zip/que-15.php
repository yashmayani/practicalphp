<?php

$a=23;

if ($a%23==0) {
    echo "Number is divided 23.";
} 
else {
    echo "Number is not divided 23.";
}




?>