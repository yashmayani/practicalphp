<?php
$a="yash";
echo gettype($a);
echo "<br>";

$a=23;
echo gettype($a);
echo "<br>";

$a=17.5;
echo gettype($a);
echo "<br>";

$a=true;
echo gettype($a);
echo "<br>";

$a=array("yash",23,17.5);
var_dump($a);
?>