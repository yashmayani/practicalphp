<?php

// $a=0;
// while ($a <= 100) {
//     if( $a%2!=0){
//         echo $a;
//         echo "<br>";
//     }
//     $a++;

// }


for ($i=1; $i <=100 ; $i++) { 
    
    if ($i%2!=0) {
        echo $i;
        echo "<br>";
    }
}


?>
