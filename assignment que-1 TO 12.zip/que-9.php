<?php

$a=array(12,23,85,46,96,47,80,46,96,36);
 
$sum=0;
for ($i=0; $i <=9 ; $i++) { 
    $sum=$sum+$a[$i];
}
echo $sum;


?>  