<?php
 
 $name="Hello Yash";
 echo strlen($name)



?>