<?php

$a = 10;
 $b = 20;
 $c = $a + $b;
 $d = $a * $b;
 $e = $d % $c;
 echo $e;
 
 ?>