<?php

 $str1 = "One, ";
 $str2 = "Two";
 $str3 = $str1 . $str2;
 echo $str3;
 
 ?>
 