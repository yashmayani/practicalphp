<?php

$name="Hello, my name is Yash";
echo str_word_count($name);


?>