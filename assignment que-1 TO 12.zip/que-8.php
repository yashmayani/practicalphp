<?php

$name=array("yash","nixit","prince","krunal","sahil","raj");
echo var_dump($name);
echo "<br>";       
echo ($name[0]);
echo "<br>";
echo ($name[5])




?>