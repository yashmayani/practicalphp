<?php

$a=array("yash",34,12.5,"sahil","jenish sorathiya");
echo var_dump ($a);
echo "<br>";

for ($i=0; $i <=4 ; $i++) { 
      echo $a[$i];
      echo "<br>";
}



?>