<?php


$a=23;

if ($a>=1) {
   echo "This number is positive";
}
elseif ($a<0) {
    echo "This number is nagative";
}
else {
    echo "Number is zero";
}


?>